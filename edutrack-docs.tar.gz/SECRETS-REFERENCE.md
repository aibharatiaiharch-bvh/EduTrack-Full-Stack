# EduTrack — Accounts & Secrets Reference

## Google Cloud Console
- **URL:** https://console.cloud.google.com
- **Service Account Email:** (same value as GOOGLE_SERVICE_ACCOUNT_EMAIL below)
- **Keys:** 2 keys exist — use the one matching your JSON download
- **Sheet ID:** 1CwS-vj_Qb2gc3VQ5bwpONCNKjibwMCqMOZD_HLT8rQo

---

## Replit Secrets (lock icon in sidebar)
| Secret Name                  | Value                                      |
|------------------------------|--------------------------------------------|
| GOOGLE_SERVICE_ACCOUNT_EMAIL | your-service-account@project.iam.gserviceaccount.com |
| GOOGLE_PRIVATE_KEY           | -----BEGIN PRIVATE KEY----- ... -----END PRIVATE KEY----- |

---

## Railway (API Server)
- **URL:** https://workspaceapi-server-production-ecd7.up.railway.app
- **Dashboard:** https://railway.app

| Variable Name                | Value                                      |
|------------------------------|--------------------------------------------|
| GOOGLE_SERVICE_ACCOUNT_EMAIL | same as Replit                             |
| GOOGLE_PRIVATE_KEY           | same as Replit                             |
| DEFAULT_SHEET_ID             | 1CwS-vj_Qb2gc3VQ5bwpONCNKjibwMCqMOZD_HLT8rQo |
| PRINCIPAL_EMAIL              | (principal's login email)                  |
| PRINCIPAL_NAME               | (principal's display name)                 |
| DEVELOPER_EMAIL              | (developer login email)                    |
| DEVELOPER_NAME               | (developer display name)                   |

---

## Netlify (Frontend)
- **URL:** https://edutrack-repgitnet.netlify.app
- **Custom domain (pending):** your subdomain
- **Dashboard:** https://app.netlify.com

| Variable Name                | Value                                      |
|------------------------------|--------------------------------------------|
| VITE_API_BASE_URL            | https://workspaceapi-server-production-ecd7.up.railway.app |

---

## Anthropic API (for future use)
| Where      | Variable Name     | Value              |
|------------|-------------------|--------------------|
| Railway    | ANTHROPIC_API_KEY | sk-ant-api03-...   |
| Replit     | ANTHROPIC_API_KEY | sk-ant-api03-...   |

---

## GitHub
- Connected to Replit via auto-push script
- Auto-pushes every 5 minutes when there are new commits
- Railway auto-deploys when GitHub main branch is updated
